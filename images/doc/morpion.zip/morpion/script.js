var morpion = [
    [0 , 0 , 0],
    [0 , 0 , 0],
    [0 , 0 , 0]
];

var joueurs = ['x', 'o'];
var turns = 0 ;

$('#morpion').find('.case').one('click' , function(joueur) {

    var joueur = joueurs[turns % 2];
    turns++;

    var row = $(this).attr('row') - 1;
    var col = $(this).attr('col') - 1;

    morpion[row][col] = joueur;

    $(this).addClass(joueur);

    if( turns === 9){
        setTimeout(function(){
            alert('vous avez perdu');
            location.reload();
        }, 250);
    }



    if (
        // check horizontal = col
        morpion[0][0] === joueur && morpion[1][0] === joueur && morpion[2][0] === joueur ||
        morpion[0][1] === joueur && morpion[1][1] === joueur && morpion[2][1] === joueur ||
        morpion[0][2] === joueur && morpion[1][2] === joueur && morpion[2][2] === joueur ||
        // check vertical = row
        morpion[0][0] === joueur && morpion[0][1] === joueur && morpion[0][2] === joueur ||
        morpion[1][0] === joueur && morpion[1][1] === joueur && morpion[1][2] === joueur ||
        morpion[2][0] === joueur && morpion[2][1] === joueur && morpion[2][2] === joueur ||
        // check diagonal
        morpion[0][0] === joueur && morpion[1][1] === joueur && morpion[2][2] === joueur ||
        morpion[0][2] === joueur && morpion[1][1] === joueur && morpion[2][0] === joueur
    ) {
        setTimeout(function(){
            alert(joueur + ' ' + 'a gagné');
            location.reload();
        }, 250);
    }
});
